/**
 * Plant.java
 */

class Plant extends Organism {
  Plant(int x,int y,int health) {
    super(x,y,health);
  }
}
