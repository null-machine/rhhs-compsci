/* FloorPlan.java
 * Generates and displays a floor plan from tables
 * @Author Glen Wang and Bryan Zhang
 * 12/02/19
 */

//Graphics &GUI imports
import javax.imageio.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Toolkit;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.GridLayout;
import javax.swing.JButton;
//import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JTextField;

// listener
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.MouseInfo;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

//Util
import java.util.ArrayList;
import java.util.Scanner;



public class FloorPlan extends JFrame implements ActionListener {
    
    // class variables
    private JFrame mainWindow;
    private TablePanel tablePanel;
    private JTextField search;
    
    private double gridToScreenRatio;
    private int screenWidth;
    private int screenHeight;
    private int gridWidth;
    private int gridHeight;
    private ArrayList<Table> tables;
    private ArrayList<Rectangle> rectangles;
    private Table[][] tableLayout;
    
    boolean mouseDrag = false;
    private int prevMouseX = 0;
    private int prevMouseY = 0;
    private int mouseX = 0;
    private int mouseY = 0;
    
    // constructor - this runs first
    FloorPlan() {
        super("Floor Plan");
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(Toolkit.getDefaultToolkit().getScreenSize());
        this.setResizable(true);
        
        screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
        screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
        
        //this.setLayout(new FlowLayout());
        tablePanel = new TablePanel();
        this.add(tablePanel);
        ControlPanel cp = new ControlPanel();
        cp.setPreferredSize(new Dimension(screenWidth / 3, 100));
        search = new JTextField(1);
        search.addActionListener(this);
        search.setPreferredSize(new Dimension(screenWidth / 5, 20));
        cp.add(search);
        this.add(cp, BorderLayout.LINE_START);
        
        rectangles = new ArrayList<Rectangle>();
        for (int i = -1000; i < 1000; i += 100) {
            for (int j = -1000; j < 1000; j += 100) {
            rectangles.add(new Rectangle(j, i, 70, 70));
            }
        }
        MyMouseListener mouseListener = new MyMouseListener();
        this.addMouseListener(mouseListener);
        
        this.requestFocusInWindow(); //make sure the frame has focus   
        
        this.setVisible(true);
        //Start the game loop in a separate thread
        Thread t = new Thread(new Runnable() { public void run() { stuff(); }}); //start the gameLoop 
        t.start();
        
        Thread t2 = new Thread(new Runnable() { public void run() {mmmYes(); }});
        t2.start();
        
        //MyKeyListener keyListener = new MyKeyListener();
        //this.addKeyListener(keyListener);
    }
    
    public void mmmYes () {
        while (true) {
            try{ Thread.sleep(1);} catch (Exception exc){}  //delay
            if (mouseDrag) {
                mouseX = MouseInfo.getPointerInfo().getLocation().x;
                mouseY = MouseInfo.getPointerInfo().getLocation().y;
                int xDiff = mouseX - prevMouseX;
                int yDiff = mouseY - prevMouseY;
                if (xDiff != 0 && yDiff != 0) {
                    for (int i = 0; i < rectangles.size(); i++) {
                        rectangles.get(i).translate(xDiff, yDiff);
                    }
                    prevMouseX = mouseX;
                    prevMouseY = mouseY;
                }
            }
            
        }
    }
    
    public void actionPerformed(ActionEvent e) {
		int input = Integer.parseInt(search.getText());
		int x = (int)rectangles.get(input).getX();
        int y = (int)rectangles.get(input).getY();
        int xDiff = screenWidth / 2 - x - 35;
        int yDiff = screenHeight / 2 - y - 35;
        for (int i = 0; i < rectangles.size(); i++) {
			rectangles.get(i).translate(xDiff, yDiff);
        }
            
    }
    
    public void stuff () {
        Scanner sc = new Scanner(System.in);
        int input = 0;
        do {
            System.out.println("Enter table number of table you want to find: ");
            input = sc.nextInt();
            int x = (int)rectangles.get(input).getX();
            int y = (int)rectangles.get(input).getY();
            int xDiff = screenWidth / 2 - x - 35;
            int yDiff = screenHeight / 2 - y - 35;
            for (int i = 0; i < rectangles.size(); i++) {
                rectangles.get(i).translate(xDiff, yDiff);
            }
        } while (input != -1);
    }
    
    // class instantiated in constructor
    private class TablePanel extends JPanel {
        public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            for (int i = 0; i < rectangles.size(); i++) {
                g.drawRect((int)rectangles.get(i).getX(), (int)rectangles.get(i).getY(), 70 ,70);
                g.drawString(Integer.toString(i), (int)rectangles.get(i).getX() + 35, (int)rectangles.get(i).getY() + 35);
            }
            g.drawOval(screenWidth/2 - 5, screenHeight/2 - 5, 10, 10);
            
            repaint();
        }
    }
    
    private class ControlPanel extends JPanel {
		public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            repaint();
        }
	}
    
    private class MyMouseListener implements MouseListener {
        
        public void mouseClicked(MouseEvent e) {
            
        }
        
        public void mousePressed(MouseEvent e) {
            prevMouseX = e.getX();
            prevMouseY = e.getY();
            mouseDrag = true;
        }
        
        public void mouseReleased(MouseEvent e) {
            mouseDrag = false;
        }
        
        public void mouseEntered(MouseEvent e) {
        }
        
        public void mouseExited(MouseEvent e) {
        }   
    }
}
