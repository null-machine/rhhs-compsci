/* FloorPlan.java
 * Generates and displays a floor plan from tables
 * @Author Glen Wang and Bryan Zhang
 * 12/02/19
 */

// graphics
import javax.imageio.*;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Color;

// gui
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JTextField;

// listeners
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// util
import java.util.ArrayList;

public class FloorPlan extends JFrame {
    
    // class variables
    private ArrayList<Table> tables;
    private Table[][] tableLayout;
    
    FloorPlan() {
        
        // config window
        super("Floor Plan");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1280, 720);
        this.setResizable(false);
        this.requestFocusInWindow();
        this.setVisible(true);
        
        // add panels
        this.setLayout(new BorderLayout());
        Renderer renderer = new Renderer(); // declared bc editor needs a ref
        this.add(new Editor(renderer), BorderLayout.WEST);
        this.add(renderer, BorderLayout.CENTER);
        this.add(new Inspector(), BorderLayout.EAST);
        System.out.println("all components added!");
        this.pack(); // absolute prankster
    }
    
    
    // inner classes
    
    /**
     * renders, pans and repositions all the tables 
     * @author Bryan Zhang and Glen Wang
     * @version 1.0
     **/
    private class Renderer extends JPanel implements MouseListener, KeyListener {
        
        //Class Variables
        private boolean mouseLeftDown;
        private boolean mouseRightDown;
        private boolean spacePressed;
        private int mouseX;
        private int mouseY;
        private int prevMouseX;
        private int prevMouseY;
        private Rectangle mouseBox;
        private Rectangle hoverBox;
        private Rectangle selectedBox;
        private long clickedTime;
        
        private ArrayList<Rectangle> rects;
        public ArrayList<Rectangle> getRects() { return rects; }
        
        /**
         * Renderer
         * creates and maintains the center panel of the floor plan
         */
        Renderer() {
            System.out.println("renderer initialized!");
            this.setPreferredSize(new Dimension(640, 720));
            spacePressed = false;
            mouseLeftDown = false;
            mouseRightDown = false;
            prevMouseX = 0;
            prevMouseY = 0;
            mouseX = 0;
            mouseY = 0;
            clickedTime = (int)System.nanoTime();
            mouseBox = new Rectangle(0, 0, 1, 1);
            rects = new ArrayList<Rectangle>();
            for (int i = -1000; i < 1000; i += 100) {
                for (int j = -1000; j < 1000; j += 100) {
                    rects.add(new Rectangle(j, i, 70, 70));
                }
            }
            
            // activating class
            this.addMouseListener(this); // dab hard for avoiding clutter-y inner classes
            this.addKeyListener(this);
            Thread updater = new Thread(new Runnable() { public void run() { update(); } });
            updater.start();
        }
        
        /**
         * pan
         * translates all the rects by shiftX and shiftY
         * @param two ints representing x shift and y shift
         */
        public void pan(int shiftX, int shiftY) {
            for(Rectangle rect : rects) rect.translate(shiftX, shiftY);
            //System.out.println("panned");
        }
        
        public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            setBackground(new Color(254, 255, 229)); 
            paintTables(g);
            repaint();
        }
        
        /**
         * update
         * pans tables by translating each of them based on shiftX and shiftY per frame
         */
        private void update() {
            while (true) {
                hoverBox = null;
                for (int i = 0; i < rects.size(); i++) {
                    if (mouseBox.intersects(rects.get(i))) {
                        hoverBox = rects.get(i);
                    }
                }
                try{ Thread.sleep(1); } catch (Exception exc) {}
                Point mousePosition = this.getMousePosition();
                if (mousePosition != null) {
                    mouseX = (int)mousePosition.getX();
                    mouseY = (int)mousePosition.getY();
                    mouseBox.setLocation(mouseX, mouseY);
                    int xDiff = mouseX - prevMouseX;
                    int yDiff = mouseY - prevMouseY;
                    if (mouseRightDown) {
                        if (xDiff != 0 || yDiff != 0) {
                            for (int i = 0; i < rects.size(); i++) {
                                rects.get(i).translate(xDiff, yDiff);
                            }
                            prevMouseX = mouseX;
                            prevMouseY = mouseY;
                        }
                    } else if (!mouseLeftDown && System.nanoTime() - clickedTime < 200000000  && (hoverBox != null)) {
                        System.out.println("ITS TIMMEEE TOO INSPEECTTT!!!!!!");
                        clickedTime = 0;
                    } else if ((mouseLeftDown) && (selectedBox != null)) {
                        if (xDiff != 0 || yDiff != 0) {
                            clickedTime = 0;
                            selectedBox.translate(xDiff, yDiff);
                            prevMouseX = mouseX;
                            prevMouseY = mouseY;
                        }
                    }
                }
            }
        }
        
        /**
         * paintTables
         * translates all the rects by shiftX and shiftY
         * @param two ints representing x shift and y shift
         */
        private void paintTables(Graphics g) {
            for (int i = 0; i < rects.size(); ++i) { // foreach
                g.drawRect((int)rects.get(i).getX(), (int)rects.get(i).getY(), 70 ,70);
                g.drawString(Integer.toString(i), (int)rects.get(i).getX() + 35, (int)rects.get(i).getY() + 35);
            }
            //System.out.println("tables painted");
        }
        
        // mouse listeners
        public void mouseClicked(MouseEvent e) {
        }
        public void mousePressed(MouseEvent e) {
            if (e.getButton() == MouseEvent.BUTTON1) {
                prevMouseX = (int)this.getMousePosition().getX();
                prevMouseY = (int)this.getMousePosition().getY();
                mouseLeftDown = true;
                clickedTime = System.nanoTime();
                for (int i = 0; i < rects.size(); i++) {
                    if (mouseBox.intersects(rects.get(i))) {
                        selectedBox = rects.get(i);
                    }
                }
            } else if (e.getButton() == MouseEvent.BUTTON3) {
                prevMouseX = (int)this.getMousePosition().getX();
                prevMouseY = (int)this.getMousePosition().getY();
                mouseRightDown = true;
            }
        }
        public void mouseReleased(MouseEvent e) {
            if (e.getButton() == MouseEvent.BUTTON1) {
                selectedBox = null;
                mouseLeftDown = false;
            } else if (e.getButton() == MouseEvent.BUTTON3) {
                mouseRightDown = false;
            }
        }
        public void mouseEntered(MouseEvent e) {
        }
        public void mouseExited(MouseEvent e) {
        }
        
        // key listeners
        public void keyTyped(KeyEvent e) {  
        }   
        public void keyPressed(KeyEvent e) {
            if ((e.getKeyCode() == KeyEvent.VK_SPACE)) {
                spacePressed = true;
            }
            // close display if esc is pressed
            if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                System.exit(0);
            }
        }
        public void keyReleased(KeyEvent e) {
            if ((e.getKeyCode() == KeyEvent.VK_SPACE)) {
                spacePressed = false;
            }
        }
    }
    
    
    /**
     * a toolkit for floor plan manipulation 
     * @author Bryan Zhang and Glen Wang
     * @version 1.0
     **/
    private class Editor extends JPanel implements ActionListener {
        
        private JTextField search;
        private Renderer renderer; // ref for search function
        
        /**
         * Editor
         * creates and maintains the left panel of the floor plan
         * @param a Renderer for search()
         */
        Editor(Renderer renderer) {
            System.out.println("editor initialized!");
            this.renderer = renderer;
            this.setPreferredSize(new Dimension(320, 720));
            
            // add search
            search = new JTextField();
            search.addActionListener(this);
            search.setPreferredSize(new Dimension(200, 20));
            this.add(search);
            
            // add other components
        }
        
        public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            setBackground(new Color(255, 235, 209)); 
            repaint();
        }
        
        /**
         * actionPerformed
         * pans the searched rectangle into the center of the screen
         * (it's the search() function but in disguise)
         * @param an ActionEvent that nobody really understands
         */
        public void actionPerformed(ActionEvent e) {
            int input = Integer.parseInt(search.getText()); // add clamping later for out of bounds
            ArrayList<Rectangle> rects = renderer.getRects();
            int x = (int)rects.get(input).getX();
            int y = (int)rects.get(input).getY();
            renderer.pan(320 - x - 35, 360 - y - 35); // 640, 360 is the screen center, inaccurate but im not sure why      Bryan: nope 320, 360 is screen center cause 640 is the width of the jframe in the middle
        }
    }
    
    /**
     * displays info of selected tables
     * @author Bryan Zhang and Glen Wang
     * @version 1.0
     **/
    private class Inspector extends JPanel {
        
        Inspector() {
            System.out.println("inspector initialized!");
            this.setPreferredSize(new Dimension(320, 720));
        }
        
        public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            setBackground(new Color(255, 235, 209)); 
            repaint();
        }
        
        // boo
    }
}
