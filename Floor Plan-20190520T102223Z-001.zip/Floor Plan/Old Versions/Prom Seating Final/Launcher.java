import java.util.ArrayList;

class Launcher {
	
	public static void main(String[] args) throws Exception {
        
        TicketingSystem ts = new TicketingSystem();
        //SeatingAlg sa = new SeatingAlg();
        //ArrayList<Table> tables = sa.generateTables(ts.getStudents()); // need to check
        
        //FloorPlan fp = new FloorPlan();
        //fp.generateFloorPlan(tables);
        //fp.displayFloorPlan();
    }
}
