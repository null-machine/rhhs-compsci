/* FloorPlan.java
 * Generates and displays a floor plan from tables
 * @Author Glen Wang and Bryan Zhang
 * 12/02/19
 */

// graphics
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Color;

// gui
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;

// util
import java.util.ArrayList;

class FloorPlan extends JFrame {
    
    public ArrayList<Table> tables;
    public ArrayList<Rectangle> tableRects;
    public ArrayList<Integer> tableTargets;
    public ArrayList<Integer> miscTargets;
    
    private Editor editor;
    private Renderer renderer;
    private Inspector inspector;
    
    FloorPlan() {
        
        // create jframe
        super("Floor Plan");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1280, 720);
        this.setResizable(false);
    }
    
    private void update() {
        while(true) {
            try{ Thread.sleep(20); } catch (Exception exc) {}
            renderer.update();
            inspector.update(tableTargets);
        }
    }
    
    public void generateFloorPlan(ArrayList<Table> tables) {
        
        this.tables = tables;
        tableRects = new ArrayList<Rectangle>();
        tableTargets = new ArrayList<Integer>();
        miscTargets = new ArrayList<Integer>();
        
        editor = new Editor(tableRects, tableTargets);
        renderer = new Renderer(tableRects, tableTargets, miscTargets);
        inspector = new Inspector(tableTargets, tables);
        
        int index = 0;
        for (int i = 0; i < Math.ceil(Math.sqrt(tables.size())); ++i) {
            for (int j = 0; j < Math.ceil(Math.sqrt(tables.size())); ++j) {
                if(index < tables.size()) {
     tableRects.add(new Rectangle(j * 100, i * 100, 70, 70));
     ++index;
    }
            }
        }
        
        this.setLayout(new BorderLayout());
        this.add(editor, BorderLayout.WEST);
        this.add(renderer, BorderLayout.CENTER);
        this.add(inspector, BorderLayout.EAST);
        this.pack(); // absolute prankster
    }
    
    public void displayFloorPlan() {
        this.requestFocusInWindow();
        this.setVisible(true);
        // launch updater
        Thread updater = new Thread(new Runnable() { public void run() { update(); } });
        updater.start();
    }
}
