public class Toohs {
	public static void main(String[] args) {
		new StartingFrame();
	}
}