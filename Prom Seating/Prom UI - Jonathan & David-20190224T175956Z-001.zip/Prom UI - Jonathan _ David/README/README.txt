README for Jonathan and David's prom program UI

All the class files needed withing our program is included in this drive.
This is currently a work in progress and we will continue to push updates to the codebase.
This project uses custom fonts, so ensure that the robot.ttf files are located in your source and production folder.


You can contact us at:
Jonathan:
647-638-4839
jonathanxu25@gmail.com
David:
426-821-4836

We can customize color schemes to your request, will put your custom code in your respective folder.

Thanks for your purchase! We look forward to making an awesome project with you.