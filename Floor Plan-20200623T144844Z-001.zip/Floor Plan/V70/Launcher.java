class Launcher {
 
 public static void main(String[] args) throws Exception {
        TicketingSystem ts = new TicketingSystem();
    }
}
