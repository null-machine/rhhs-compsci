
// graphics
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Color;

// gui
import javax.swing.JPanel;
import java.awt.Dimension;

// listeners
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;

// util
import java.util.ArrayList;

/**
 * Renderer.java
 * creates and maintains the center panel of the floor plan
 * @author Bryan Zhang and Glen Wang
 * @version 1.0
 **/
class Renderer extends JPanel implements KeyListener {
    
    private Tool[] tools;
    private Tool currentTool;
    private Tool prevTool;
    private ArrayList<Rectangle> tableRects;
    private ArrayList<Rectangle> miscRects;
    private ArrayList<Rectangle> targets;
    private Rectangle selectionBox;
    
    /**
     * Renderer
     * creates and maintains the center panel of the floor plan
     */
    Renderer(ArrayList<Rectangle> tableRects, ArrayList<Rectangle> targets) {
        this.tableRects = tableRects;
        this.targets = targets;
        miscRects = new ArrayList<Rectangle>();
        selectionBox = new Rectangle (0, 0, 0, 0);
        
        tools = new Tool[4];
        tools[0] = new Pan(this, tableRects, miscRects);
        tools[1] = new Select(this, tableRects, miscRects, targets, selectionBox);
        tools[2] = new Inspect(this, tableRects, targets);
        tools[3] = new Draw(this, miscRects, targets);
        currentTool = tools[1];
        prevTool = null;
        this.addMouseListener(tools[1]);
        this.addKeyListener(this);
        System.out.println("renderer initialized!");
        this.setPreferredSize(new Dimension(640, 720));
        
        for (int i = -1000; i < 1000; i += 100) {
            for (int j = -1000; j < 1000; j += 100) {
                tableRects.add(new Rectangle(j, i, 70, 70)); // hard code
            }
        }
    }
    
    public void paintComponent(Graphics g) { 
        super.paintComponent(g);
        setDoubleBuffered(true);
        setBackground(new Color(254, 255, 229)); 
        paintTables(g);
        paintTargets(g);
        paintMiscRects(g);
        //System.out.println(selectionBox.getX() + " " + selectionBox.getY());
        g.drawRect((int)selectionBox.getX(), (int)selectionBox.getY(), (int)selectionBox.getWidth(), (int)selectionBox.getHeight());
        repaint();
    }
    
    /**
     * paintTargets
     * Paints over targeted rectangles to indicate selected rectangles
     * @param g Used to be able to draw;
     */
    private void paintTargets(Graphics g) {
        for (Rectangle rect: targets) { // foreach
            g.setColor(new Color(0, 0, 0, 30));
            g.fillRect((int)rect.getX(), (int)rect.getY(), (int)rect.getWidth() , (int)rect.getHeight());
        }
        //System.out.println("tables painted");
    }
    
    /**
     * paintTables
     * translates all the tableRects by shiftX and shiftY
     * @param two ints representing x shift and y shift
     */
    private void paintTables(Graphics g) {
        for (int i = 0; i < tableRects.size(); ++i) { // foreach
            Rectangle rect = tableRects.get(i);
            g.setColor(Color.BLACK);
            g.drawRect((int)rect.getX(), (int)rect.getY(), (int)rect.getWidth() , (int)rect.getHeight());
            g.drawString(Integer.toString(i), (int)rect.getX() + (int)rect.getWidth() / 2, (int)rect.getY() + (int)rect.getHeight() / 2);
        }
        //System.out.println("tables painted");
    }
    
    /**
     * paintMiscRects
     * translates all the tableRects by shiftX and shiftY
     * @param two ints representing x shift and y shift
     */
    private void paintMiscRects(Graphics g) {
        for (int i = 0; i < miscRects.size(); i++) { // foreach
            Rectangle rect = miscRects.get(i);
            g.setColor(Color.BLACK);
            g.drawRect((int)rect.getX(), (int)rect.getY(), (int)rect.getWidth() , (int)rect.getHeight());
        }
        //System.out.println("tables painted");
    }
    
    /**
     * update
     * updates and stuff
     **/
    public void update () {
        currentTool.update();
    }
    
    public void keyTyped(KeyEvent e) {
    }
       
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                System.out.println("TO THE LEFT TO THE LEFT");
                for (Rectangle rect: targets) {
                    rect.translate(-1, 0);
                }
            case KeyEvent.VK_SPACE:
                if (prevTool == null) {
                    prevTool = currentTool;
                    currentTool = tools[0];
                    this.removeMouseListener(this.getMouseListeners()[0]);
                    this.addMouseListener(currentTool);
                }
        }
    }
    
    
    /**
     * keyReleased
     * manages functionality mapped to keys
     * @param a KeyEvent for key info
     */
    public void keyReleased(KeyEvent e) {
        switch(e.getKeyCode()) {
            case KeyEvent.VK_SPACE:
                currentTool = prevTool;
                prevTool = null;
                this.removeMouseListener(this.getMouseListeners()[0]);
                this.addMouseListener(currentTool);
                break;
            case KeyEvent.VK_S: 
                currentTool = tools[1];
                System.out.println("SSSSSSSSSSNNNAKKKEEEE");
                this.removeMouseListener(this.getMouseListeners()[0]);
                this.addMouseListener(currentTool);
                break;
            case KeyEvent.VK_A: 
                currentTool = tools[2];
                this.removeMouseListener(this.getMouseListeners()[0]);
                this.addMouseListener(currentTool);
                break;
            case KeyEvent.VK_D:
                currentTool = tools[3];
                this.removeMouseListener(this.getMouseListeners()[0]);
                this.addMouseListener(currentTool);
                break;
            case KeyEvent.VK_ENTER:
                targets.clear();
        }
    }
}
