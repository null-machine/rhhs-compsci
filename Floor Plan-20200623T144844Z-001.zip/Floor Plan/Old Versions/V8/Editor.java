
// graphics
import javax.imageio.*;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Color;

// gui
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Dimension;

// listeners
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// util
import java.util.ArrayList;

/**
 * Editor.java
 * a toolkit for floor plan manipulation 
 * @author Bryan Zhang and Glen Wang
 * @version 1.0
 **/
class Editor extends JPanel implements ActionListener {
    
    private Renderer renderer; // ref for search function
    private ArrayList<Rectangle> tableRects;
    private ArrayList<Integer> tableTargets;
    
    private JTextField search;
    private JButton inspect;
    private JButton select;
    private JButton pan;
    private JButton draw;
    
    /**
     * Editor
     * creates and maintains the left panel of the floor plan
     * @param a Renderer for search()
     */
    Editor(ArrayList<Rectangle> tableRects, ArrayList<Integer> tableTargets) {
        this.tableRects = tableRects;
        System.out.println("editor initialized!");
        this.renderer = renderer;
        this.tableTargets = tableTargets;
        this.setPreferredSize(new Dimension(320, 720));
        
        search = new JTextField();
        search.addActionListener(this);
        search.setPreferredSize(new Dimension(200, 20));
        search.setActionCommand("search");
        this.add(search);
        
//        inspect = new JButton("inspect");
//        inspect.addActionListener(this);
//        inspect.setPreferredSize(new Dimension(200, 20));
//        inspect.setActionCommand("inspect");
//        this.add(inspect);
//        
//        select = new JButton("select");
//        select.addActionListener(this);
//        select.setPreferredSize(new Dimension(200, 20));
//        select.setActionCommand("select");
//        this.add(select);
//        
//        pan = new JButton("pan");
//        pan.addActionListener(this);
//        pan.setPreferredSize(new Dimension(200, 20));
//        pan.setActionCommand("pan");
//        this.add(pan);
//        
//        draw = new JButton("draw");
//        draw.addActionListener(this);
//        draw.setPreferredSize(new Dimension(200, 20));
//        draw.setActionCommand("draw");
//        this.add(draw);
        
        // add other components
    }
    
    public void paintComponent(Graphics g) { 
        super.paintComponent(g);
        setDoubleBuffered(true);
        setBackground(new Color(62, 55, 53)); 
        repaint();
    }
    
    /**
     * actionPerformed
     * pans the searched rectangle into the center of the screen
     * (it's the search() function but in disguise)
     * @param an ActionEvent that nobody really understands
     */
    public void actionPerformed(ActionEvent e) {
  
  switch(e.getActionCommand()) {
//   case "inspect":
//    System.out.println("switch to inspect");
//    renderer.setTool(1);
//    break;
//   case "select":
//    System.out.println("switch to select");
//    renderer.setTool(2);
//    break;
//   case "pan":
//    System.out.println("switch to pan");
//    renderer.setTool(0);
//    break;
//   case "draw":
//    System.out.println("switch to draw");
//    renderer.setTool(3);
//    break;
   case "search":
    int input = Integer.parseInt(search.getText()); // add clamping later for out of bounds
    int x = (int)tableRects.get(input).getX();
    int y = (int)tableRects.get(input).getY();
    tableTargets.add(input);
    for(Rectangle rect : tableRects) {
     rect.translate(320 - x - 35, 360 - y - 35);
    }
    break;
  }
        
    }
}

