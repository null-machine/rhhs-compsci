/* FloorPlan.java
 * Generates and displays a floor plan from tables
 * @Author Glen Wang and Bryan Zhang
 * 12/02/19
 */

// graphics
import javax.imageio.*;
import java.awt.Graphics;
import java.awt.Rectangle;

// gui
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JButton;
import javax.swing.JTextField;

// listeners
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.MouseInfo;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

// util
import java.util.ArrayList;

public class FloorPlan extends JFrame {
    
    // class variables
    private int gridWidth;
    private int gridHeight;
    
    private ArrayList<Table> tables;
    private Table[][] tableLayout;
    
    FloorPlan() {
        
        // config window
        super("Floor Plan");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(1280, 720);
        this.setResizable(false);
        this.requestFocusInWindow();
        this.setVisible(true);
        
        // add panels
        this.setLayout(new BorderLayout());
        Renderer renderer = new Renderer(); // declared bc editor needs a ref
        this.add(new Editor(renderer), BorderLayout.WEST);
        this.add(renderer, BorderLayout.CENTER);
        this.add(new Inspector(), BorderLayout.EAST);
        System.out.println("all components added!");
        this.pack(); // absolute prankster
    }
    
    
    // inner classes
    
    /**
	 * renders, pans and repositions all the tables 
	 * @author Bryan Zhang and Glen Wang
	 * @version 1.0
	 **/
    private class Renderer extends JPanel implements MouseListener {
		
		private int prevMouseX;
		private int prevMouseY;
		
		private ArrayList<Rectangle> rects;
		public ArrayList<Rectangle> getRects() { return rects; }
		
		/**
		 * Renderer
		 * creates and maintains the center panel of the floor plan
		 */
		Renderer() {
			System.out.println("renderer initialized!");
			this.setPreferredSize(new Dimension(640, 720));
			
			rects = new ArrayList<Rectangle>();
			for (int i = -1000; i < 1000; i += 100) {
				for (int j = -1000; j < 1000; j += 100) {
					rects.add(new Rectangle(j, i, 70, 70));
				}
			}
			
			// activating class
			this.addMouseListener(this); // dab hard for avoiding clutter-y inner classes
			Thread updater = new Thread(new Runnable() { public void run() { update(); } });
			updater.start();
		}
		
		/**
		 * pan
		 * translates all the rects by shiftX and shiftY
		 * @param two ints representing x shift and y shift
		 */
		public void pan(int shiftX, int shiftY) {
			for(Rectangle rect : rects) rect.translate(shiftX, shiftY);
			//System.out.println("panned");
		}
		
		public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            paintTables(g);
            repaint();
        }
        
        /**
		 * update
		 * pans tables by translating each of them based on shiftX and shiftY per frame
		 */
		private void update() {
			while (true) {
				try{ Thread.sleep(20); } catch (Exception exc) {}
				// code here gets executed every frame
			}
		}
        
        /**
		 * paintTables
		 * translates all the rects by shiftX and shiftY
		 * @param two ints representing x shift and y shift
		 */
        private void paintTables(Graphics g) {
			for (int i = 0; i < rects.size(); ++i) { // foreach
                g.drawRect((int)rects.get(i).getX(), (int)rects.get(i).getY(), 70 ,70);
                g.drawString(Integer.toString(i), (int)rects.get(i).getX() + 35, (int)rects.get(i).getY() + 35);
            }
            //System.out.println("tables painted");
		}
		
		// mouse listeners
		
		// old panning, basically all of this is gonna get merged out of here 
        public void mousePressed(MouseEvent e) {
            //System.out.println("mouse pressed");
            prevMouseX = e.getX();
            prevMouseY = e.getY();
        }
        
        public void mouseReleased(MouseEvent e) {
			//System.out.println("mouse released");
			int shiftX = e.getX() - prevMouseX;
			int shiftY = e.getY() - prevMouseY;
			pan(shiftX, shiftY);
		}
		
        public void mouseClicked(MouseEvent e) {}
        public void mouseEntered(MouseEvent e) {}
        public void mouseExited(MouseEvent e) {}
	}
	
	/**
	 * a toolkit for floor plan manipulation 
	 * @author Bryan Zhang and Glen Wang
	 * @version 1.0
	 **/
	private class Editor extends JPanel implements ActionListener {
		
		private JTextField search;
		private Renderer renderer; // ref for search function
		
		/**
		 * Editor
		 * creates and maintains the left panel of the floor plan
		 * @param a Renderer for search()
		 */
		Editor(Renderer renderer) {
			System.out.println("editor initialized!");
			this.renderer = renderer;
			this.setPreferredSize(new Dimension(320, 720));
			
			// add search
			search = new JTextField();
			search.addActionListener(this);
			search.setPreferredSize(new Dimension(200, 20));
			this.add(search);
			
			// add other components
		}
		
		public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            repaint();
        }
        
        /**
		 * actionPerformed
		 * pans the searched rectangle into the center of the screen
		 * (it's the search() function but in disguise)
		 * @param an ActionEvent that nobody really understands
		 */
        public void actionPerformed(ActionEvent e) {
			int input = Integer.parseInt(search.getText()); // add clamping later for out of bounds
			ArrayList<Rectangle> rects = renderer.getRects();
			int x = (int)rects.get(input).getX();
			int y = (int)rects.get(input).getY();
			renderer.pan(640 - x, 360 - y); // 640, 360 is the screen center, inaccurate but im not sure why
		}
	}
	
	/**
	 * displays info of selected tables
	 * @author Bryan Zhang and Glen Wang
	 * @version 1.0
	 **/
	private class Inspector extends JPanel {
		
		Inspector() {
			System.out.println("inspector initialized!");
			this.setPreferredSize(new Dimension(320, 720));
		}
		
		public void paintComponent(Graphics g) { 
            super.paintComponent(g);
            setDoubleBuffered(true);
            repaint();
        }
        
        // boo
	}
}
