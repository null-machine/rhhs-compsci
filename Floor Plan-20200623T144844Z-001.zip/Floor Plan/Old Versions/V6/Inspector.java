// graphics
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Color;

// gui
import javax.swing.JPanel;
import javax.swing.JTextArea;
import java.awt.Dimension;

// util
import java.util.ArrayList;

/**
 * Inspector.java
 * displays info of selected tables
 * @author Bryan Zhang and Glen Wang
 * @version 1.012/02/19
 */
class Inspector extends JPanel {
    
    private JTextArea info;
    private Renderer renderer;
    private ArrayList<Integer> tableTargets;
    private ArrayList<Table> tables;
    
    Inspector(ArrayList<Integer> tableTargets, ArrayList<Table> tables) {
        this.tableTargets = tableTargets;
        this.tables = tables;
        System.out.println("inspector initialized!");
        this.setPreferredSize(new Dimension(320, 720));
        
        info = new JTextArea("infooooooo");
        info.setEditable(false);
        info.setPreferredSize(new Dimension(200, 600));
        this.add(info);
    }
    
    public void paintComponent(Graphics g) { 
        super.paintComponent(g);
        setDoubleBuffered(true);
        setBackground(new Color(255, 235, 209)); 
        repaint();
    }
    
    public void update(ArrayList<Integer> tableTargets) { // todo: update from tableTargets setter
        String displayInfo = "";
        if(tableTargets.size() == 1) {
   ArrayList<Student> students = tables.get(tableTargets.get(0)).getStudents();
   for(Student student : students) {
    displayInfo += student.getName() + "\n";
    displayInfo += student.getStudentNumber() + "\n";
    displayInfo += "\n";
   }
  } else {
   displayInfo = "nothing to display";
  }
  
        info.setText(displayInfo);
        
        //System.out.println("info updated: " + displayInfo);
    }
    // boo
}
