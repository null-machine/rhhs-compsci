interface Updatable {
    public void update();
}