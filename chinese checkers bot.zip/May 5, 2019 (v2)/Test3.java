//package checkers;

public class Test3 {
	public static void main(String[] args) {
		new Client().go();
	}
}
