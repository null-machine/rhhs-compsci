//package checkers;

/**
 * Test.java
 * @author Anthony, Eric
 * May 5, 2019
 * Use this for testing methods.
 */

public class Test {
	public static void main(String[] args) {
		new Client().go();
	}
}
