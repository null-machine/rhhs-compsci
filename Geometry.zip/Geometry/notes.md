### notes
- parallelogram is the base class for all quadrilaterals

### class interactions
- GDP determines user intent and handles gui
- when adding or modifying shapes, GDP passes the scanner to the shape class! this allows more class specific user prompts to be placed in the classes instead of the GDP, adhering to java's object oriented design
- saving and loading is done by the serializer
