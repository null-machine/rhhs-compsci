import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
class DisplayProjectile{
  int x;
  int y;
  double direction;
  int image;
  int identifier;
  static Image[][] sprites;
  static void loadAssets(){
    sprites = new Image[2][2];
    //sprites[0] = new Image[2];
    try{
      sprites[0][0] = ImageIO.read(new File("projbo10002.png"));
      sprites[0][1] = ImageIO.read(new File("projbo10001.png"));
      sprites[1][0] = ImageIO.read(new File("projbo20002.png"));
      sprites[1][1] = ImageIO.read(new File("projbo20001.png"));
    } catch(IOException e){
      System.out.println("Image loading failed");
      e.printStackTrace();
    }
  }
  DisplayProjectile(int identifier, int x, int y, int image, double direction){
    this.identifier = identifier;
    this.x = x;
    this.y = y;
    this.image = image;
    this.direction = direction;
  }
  public static Image[] getSprites(int i){
    return sprites[i];
  }
  public int getX(){
    return x;
  }
  public int getY(){
    return y;
  }
  public int getImage(){
    return image;
  }
  public double getDirection(){
    return direction;
  }
  public int getIdentifier(){
    return identifier;
  }
}