import java.awt.Rectangle;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
class Sword extends Weapon{
  private static Image [] sprites;
  private static Attack atk1;
  private static Skill skill1;
  private static int moveSpeed = 15;
  private int skill1CD;
  static void loadAssets(){
    sprites = new Image[20];
    try{
      for(int i = 1; i<=4; i++){
        sprites[i-1] = ImageIO.read(new File("sword000"+i+".png"));
      }
      for(int i = 1; i<=9; i++){
        if (i>=10){
          sprites[i+3] = ImageIO.read(new File("atksw100"+i+".png"));
        } else {
          sprites[i+3] = ImageIO.read(new File("atksw1000"+i+".png"));
        }
      }
      for(int i = 1; i<=7; i++){
        sprites[i+12] = ImageIO.read(new File("skillsw1000"+i+".png"));
      }
    } catch(IOException e){
      System.out.println("Image loading failed");
      e.printStackTrace();
    }
    int [] atk1Anim = {4, 5, 5, 6, 7, 8, 9, 10, 11, 12};
    Rectangle [][] atk1hitBox = new Rectangle [10][1];
    atk1hitBox[1][0] = new Rectangle(0, -46, 59, 65);
    atk1hitBox[2][0] = new Rectangle(0, -46, 59, 65);
    atk1 = new Attack(1, atk1Anim, atk1hitBox, 20, 3, 5, 2, -11, -50, 149, 269, null, null);
    
    int [] skill1Anim = {13, 14, 15, 16, 17, 18, 18, 18, 18, 19, 19};
    Rectangle[][] skill1Hitbox = new Rectangle [11][1];
    skill1Hitbox[2][0] = new Rectangle(13, -44, 25, 220);
    skill1Hitbox[3][0] = skill1Hitbox[1][0];
    //skill1Hitbox[3][0] = skill1Hitbox[1][0];
    double skill1Move[] = new double[11];
    skill1Move[1] = 140;
    skill1Move[4] = 5;
    skill1Move[9] = 5;;
    skill1 = new SwSkill1(skill1Anim, skill1Hitbox, skill1Move);
    //System.out.println("Assets Loaded");
    
  }
  public int getIdleX(){
    return 0;
  }
  public int getIdleY(){
    return 0;
  }
  public Image[] getSprites(){
    return this.sprites;
  }
  public Attack getAttack(int i){
    if(i == 1){
      return this.atk1;
    } else if(i == 2){
      return this.skill1;
    }
    return null;
  }
  public int getMoveSpeed(){
    return moveSpeed;
  }
  public void setSkill1Cooldown(int i){
    skill1CD = i;
  }
  public int getSkill1Cooldown(){
    //System.out.println(skill1CD);
    return skill1CD;
  }
  public void processCooldown(){
    if(skill1CD>0){
      skill1CD--;
    }
  }
}