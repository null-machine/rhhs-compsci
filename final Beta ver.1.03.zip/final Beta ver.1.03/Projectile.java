//imports
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.Shape;

class Projectile{
  private Image [] sprites;
  private int [] projectileAnim;
  private int animationCounter;
  private double x;
  private double y;
  private double moveSpeed;
  private double xVelocity;
  private double yVelocity;
  private Rectangle [][] hitbox;
  private double direction;
  private int damage;
  private int moveStun;
  private int hitInvul;
  private int team;
  private int identifier;
  private boolean expire;
  
  //constructor of the Projectile class, this takes in all necessary variables and assigns them to this object
  Projectile (int [] projectileAnim, double moveSpeed, Rectangle [][] hitbox, int damage, int stun, int identifier){
    this.projectileAnim = projectileAnim;
    this.moveSpeed = moveSpeed;
    this.hitbox = hitbox;
    this.animationCounter = 0;
    this.damage = damage;
    this.moveStun = stun;
    this.hitInvul = 0;
    this.identifier = identifier;
  }
  
  Projectile (Projectile projectileCopy, double x, double y, double direction, int team){
    this.projectileAnim = projectileCopy.getProjectileAnim();
    //this.xVelocity = projectileCopy.getXVelocity();
    //this.yVelocity = projectileCopy.getYVelocity();
    this.hitbox = projectileCopy.getHitBox();
    this.x = x;
    this.y = y;
    this.moveSpeed = projectileCopy.getMoveSpeed();
    this.direction = direction;
    this.animationCounter = 0;
    this.damage = projectileCopy.getDamage();
    this.moveStun = projectileCopy.getMoveStun();
    this.xVelocity = Math.sin(direction)*moveSpeed;
    this.yVelocity = -Math.cos(direction)*moveSpeed;
    this.identifier = projectileCopy.getIdentifier();
    this.team = team;
    this.expire = false;
    
    //x+=xVelocity;
    //y+=yVelocity;
  }
  
  public void setExpire(){
    expire = true;
  }
  
  public double getMoveSpeed(){
    return moveSpeed;
  }
  
  /*
   * getHitBox
   * getter for hitbox
   * @param none
   * @return Rectangle 2D array hitbox, the raw hitbox of this object
   */
  public Rectangle[][] getHitBox () {
    return hitbox;
  }
  
  public boolean process(){
    
    if(x<-10 || y<-10 || x>1260 || y>1510 || expire){
      return false;
    }
    
    //increase it's animation counter if it's less than it's length
    if (animationCounter<projectileAnim.length-1){
      animationCounter++;
    }
    
    //move projectile 
    x+=xVelocity;
    y+=yVelocity;
    
    
    //return true if this projectile is not to be removed
    return true;
  }
  
  /*
   * getCurrentHitBox
   * alternate getter for hitbox
   * @param int j, the index of the hitbox array to be accessed
   * @return the current hitbox of this object, scaled to direction and the projectile's current location
   */
  public Shape getCurrentHitBox(int j){
    //make sure the animationCounter value is valid
    if (animationCounter == -1){
      animationCounter = 0;
    }
    
    if(hitbox[animationCounter][j]!=null){
      AffineTransform t = new AffineTransform();
      t.rotate(direction, x+(DisplayProjectile.getSprites(identifier)[getImage()].getWidth(null)/8), y+(DisplayProjectile.getSprites(identifier)[getImage()].getHeight(null)/8));
      Rectangle tempHit = new Rectangle((int)(x+hitbox[animationCounter][j].getX()), (int)(y+hitbox[animationCounter][j].getY()), (int)hitbox[animationCounter][j].getWidth(), (int)hitbox[animationCounter][j].getHeight());
      return t.createTransformedShape(tempHit);
    }
    /*
    //return the current hitbox of this object scaled to the current location of this object and it's direction
    if (((hitBoxActive) || (duration == lingerFrames)) && (hitbox[animationCounter][j] != null)){
      if (direction.equals("left")){
        return new Rectangle((int)(x+this.getImage().getWidth(null)-hitbox[animationCounter][j].getX()-hitbox[animationCounter][j].getWidth()), (int)(y+hitbox[animationCounter][j].getY()), (int)hitbox[animationCounter][j].getWidth(), (int)hitbox[animationCounter][j].getHeight());
      } else {
        return new Rectangle ((int)(x+hitbox[animationCounter][j].getX()), (int)(y+hitbox[animationCounter][j].getY()), (int)hitbox[animationCounter][j].getWidth(), (int)hitbox[animationCounter][j].getHeight());
      }
    }*/
    return new Rectangle (0, 0, 0, 0);
  }
  
  /*
   * getSprites
   * getter for sprites
   * @param none
   * @return Image array sprites, the raw images array used in this projectile
   */
  public Image [] getSprites(){
    return sprites;
  }
  
  /*
   * getProjectileAnim
   * getter for projectileAnim
   * @param none
   * @return int array projectileAnim, the animation array of this projectile
   */ 
  public int [] getProjectileAnim(){
    return projectileAnim;
  }
  
  /*
   * getXVelocity
   * getter for xVelocity
   * @param none
   * @return int xVelocity, the horizontal velocity of this object
   */ 
  public double getXVelocity(){
    return xVelocity;
  }
  
  /*
   * getYVelocity
   * getter for yVelocity
   * @param none
   * @return int yVelocity, the vertical velocity of this object
   */ 
  public double getYVelocity(){
    return yVelocity;
  }
  
  /*
   * getX
   * getter for x
   * @param none
   * @return int x, the horizontal location of this object
   */
  public int getX(){
    return (int)(Math.round(x));
  }
  
  /*
   * getY
   * getter for y
   * @param none
   * @return int y, the vertical location of this object
   */ 
  public int getY(){
    return (int)(Math.round(y));
  }
  
  /*
   * getDirection
   * getter for direction
   * @param none
   * @return double direction, the direction of this projectile
   */ 
  public double getDirection(){
    return direction;
  }
  
  /*
   * getDamage
   * getter for damage
   * @param none
   * @return int damage, the amount of damage this projectile deals
   */ 
  public int getDamage(){
    return damage;
  }
  
  /*
   * getMoveStun
   * getter for moveStun
   * @param none
   * @return int moveStun, the amount of frames this projectile restricts movement on hit
   */ 
  public int getMoveStun(){
    return moveStun;
  }
  
  /*
   * getHitInvul
   * getter for hitInvul
   * @param none
   * @return int hitInvul, the amount of frames of invulnerability the hit player is granted
   */ 
  public int getHitInvul(){
    return hitInvul;
  }
  
  
  public int getIdentifier(){
    return identifier;
  }
  
  public int getImage(){
    return projectileAnim[animationCounter]+(team-1);
  }
  
}