import java.awt.Rectangle;
class Attack implements ProjectileSpawning{
  private int attackIdentifier;
  private int [] attackAnim;
  private int duration;
  private Rectangle [][] hitbox;
  private int damage;
  private int moveStun;
  private int selfStun;
  private int hitInvul = 2;
  private int imageX;
  private int imageY;
  private int rotateX;
  private int rotateY;
  /*private Effect [][] effect;
  private int [][][] effectLocation;*/
  private Projectile [][] projectile;
  private double [][][] projectileLocation;
  
  //constructor for the Attack object, takes all necessary variables and assigns them to this object
  Attack (int attackIdentifier, int [] atkAnim, Rectangle [][] hit, int damage, int moveStun, int selfStun, int hitInvul, int imageX, int imageY, int rotateX, int rotateY/*, Effect [][] effect, int [][][] effectLocation*/, Projectile [][] projectile, double[][][] projectileLocation){
    this.attackIdentifier = attackIdentifier;
    this.attackAnim = atkAnim;
    this.duration = attackAnim.length-1;
    this.hitbox = hit;
    this.damage = damage;
    this.moveStun = moveStun;
    this.selfStun = selfStun;/*
    this.effect = effect;
    this.effectLocation = effectLocation;*/
    this.projectile = projectile;
    this.projectileLocation = projectileLocation;
    this.hitInvul = hitInvul;
    this.imageX = imageX;
    this.imageY = imageY;
    this.rotateX = rotateX;
    this.rotateY = rotateY;
  }
  
  public int getAttackIdentifier(){
    return attackIdentifier;
  }
  
  /*
   * getAttackAnim
   * getter for attackAnim
   * @param int i, the index of the attackAnim array needed
   * @return the ith value of the attackAnim array (used to animate the attack and make calls to certain images)
   */ 
  public int getAttackAnim(int i){
    return attackAnim[i];
  }
  
  /*
   * getLength
   * getter for Length
   * @param none
   * @return int length, the amount of frames this attack takes
   */ 
  public int getDuration(){
    return duration;
  }
  
  /*
   * getHitInvul
   * getter for hitInvul
   * @param none
   * @return int hitInvul, the amount of frames of invulnerability the hit player is granted
   */ 
  public int getHitInvul(){
    return hitInvul;
  }
  
  /*
   * getDamage
   * getter for damage
   * @param none
   * @return int damage, the amount of damage this attack deals
   */ 
  public int getDamage(){
    return damage;
  }
  
  public int getMoveStun(){
    return moveStun;
  }
  
  
  /*
   * getHitBox
   * getter for hitbox 
   * @param none
   * @return 2D Rectangle array hitbox, the hitbox of this attack
   */ 
  public Rectangle[][] getHitBox () {
    return hitbox;
  }
  
  /*
   * getSelfStun
   * getter for selfStun
   * @param none
   * @return int selfStun, the amount of frames this attack stuns the user
   */ 
  public int getSelfStun(){
    return selfStun;
  }

  public int getImageX(){
    return imageX;
  }
  
  public int getImageY(){
    return imageY;
  }
  
  public int getRotateX(){
    return rotateX;
  }
  
  public int getRotateY(){
    return rotateY;
  }
  
  /*
   * getEffect
   * getter for effect 
   * @param int i, the index of the effect array needed
   * @return Effect effect, the effect this attack creates at the ith frame
   */ 
  /*public Effect[] getEffect(int i){
    if (effect!= null){
      return effect[i];
    }
    return null;
  }*/
  
  /*
   * getEffectX
   * getter for effectLocation 
   * @param int i and j, the index of the effectLocatin needed
   * @return int effectLocation, the location that the effect this attack creates spawn at (X coordinate)
   */ 
  /*public int getEffectX(int i, int j){
    if (effectLocation != null){
      return effectLocation[i][j][0];
    }
    return 0;
  }*/
  
  /*
   * getEffectY
   * getter for effectLocation 
   * @param int i and j, the index of the effectLocatin needed
   * @return int effectLocation, the location that the effect this attack creates spawn at (Y coordinate)
   */ 
  /*public int getEffectY(int i, int j){
    if (effectLocation != null){
      return effectLocation[i][j][1];
    }
    return 0;
  }*/
  
  /*
   * getProjectile
   * getter for projectile
   * @param int i, the index of the projectile array needed
   * @return Projectile projectile, the projectile this attack spawns at the ith frame
   */ 
  @Override
  public Projectile[] getProjectile(int i){
    if (projectile!=null){
      return projectile[i];
    }
    return null;
  }
  
  /*
   * getProjectileX
   * getter for projectileLocation 
   * @param int i and j, the index of the projectileLocatin needed
   * @return int projectileLocation, the location that the projectile this attack creates spawn at (X coordinate)
   */ 
  @Override
  public double getProjectileX(int i, int j){
    if (projectileLocation != null){
      return projectileLocation[i][j][0];
    }
    return 0;
  }
  
  /*
   * getProjectileY
   * getter for projectileLocation 
   * @param int i and j, the index of the projectileLocatin needed
   * @return int projectileLocation, the location that the projectile this attack creates spawn at (Y coordinate)
   */
  @Override
  public double getProjectileY(int i, int j){
    if (projectileLocation != null){
      return projectileLocation[i][j][1];
    }
    return 0;
  }
}