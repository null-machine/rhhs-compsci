import java.awt.Image;
abstract class Weapon{
  //private static Image [] sprites;
  //private static Attack atk1;
  /*private static Image [] sprites;
  private static int [] atk1Anim;
  static Image[] getSprites(){
    return sprites;
  }
  static int[] getAtk1Anim(){
    return atk1Anim;
  }
  static void setSprites(Image[] s){
    sprites = s;
  }
  static void setAtk1Anim(int[] a){
    atk1Anim = a;
  }*/
  public abstract int getIdleX();
  public abstract int getIdleY();
  public abstract Image[] getSprites();/*{
    return sprites;
  }*/
  public abstract Attack getAttack(int i);/*{
    return atk1;
  }*/
  public abstract int getMoveSpeed();
  public abstract int getSkill1Cooldown();
  public abstract void setSkill1Cooldown(int i);
  public abstract void processCooldown();
}