interface MovingAttack{
  public double getXMove(int i);
}