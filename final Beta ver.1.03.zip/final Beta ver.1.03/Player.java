//imports
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.Shape;

/*class Player
 * @version beta-1.03
 * @author Eric Wang
 * 06-12-19
 * This is a topdown team based action game
 * the objective of this game is to capture the enemy's objective while defending yours
 * the game is networked with a server and clients
 * server handles all calculations while clients displays the game
 * players can enter combat through melee and projectile based attacks
 * This is the class that represents the player of the class, storing all variables and methods required by the player
 */

//class starts here
class Player{
  
  //variable declaration
  //variable to do with player status
  private double x;
  private double y;
  private int health;
  private double moveSpeed = 15.0;
  private double xVelocity;
  private double yVelocity;
  private boolean movingUp;
  private boolean movingDown;
  private boolean movingLeft;
  private boolean movingRight;
  private int yDirection;
  private int xDirection;
  private int team;
  private boolean flag;
  private int [][] directionMatrix = {{3, 0, 3},
                                      {2, 0, 2},
                                      {1, 0, 1}};
  private boolean moving;
  private int moveStun;
  private int rootDuration;
  private int animationCounter;
  private int invulDuration;
  private int respawnCounter;
  private Weapon weapon;
  //attack information
  private Attack currentAction;
  private double attackDirection;
  private int actionCounter;
  private int actionStun;
  //hitboxes and hurtboxes
  private Shape [] hitbox;
  private Rectangle hurtbox;
  //animations
  private int [] runAnim = {4, 4, 5, 6, 7, 8, 8, 9, 10, 11};
  
  /**
   * GameClient
   * Constructor for the Player class
   * @param x the initial horizontal coordinate, y the initial vertical coordinate, team the team this player belongs to
   */
  Player(double x, double y, int team){
    this.x = x;
    this.y = y;
    this.team = team;
    this.flag = false;
    this.xDirection = 1;
    this.yDirection = 0;
    this.health = 100;
    this.weapon = new Sword();
  }
  
  /**
   * setWeapon
   * this method i
   * @param w, the new Weapon this player is to change to
   */
  public void setWeapon(Weapon w){
    this.weapon = w;
  }
  
   /**
    * setXDirection
    * setter for the xDirection of the player
    * the xDirection represents the horizontal direction of the player (left, middle or right)
    * @param i, the new xDirection of the player
    */ 
  public void setXDirection(int i){
    xDirection = i;
  }
   /**
    * setYDirection
    * setter for the yDirection of the player
    * the yDirection represents the vertical direction of the player (up, middle or down)
    * @param i, the new yDirection of the player
    */ 
  public void setYDirection(int i){
    yDirection = i;
  }
  
   /**
    * setMoveStun
    * setter for the moveStun of the player
    * the moveStun represents the amount of frames before this player could move again
    * @param i, the new moveStun of the player
    */ 
  public void setMoveStun(int i){
    moveStun = i;
  }
  
   /**
    * setRoot
    * setter for the rootDuration of the player
    * the rootDuration represents the amount of frames this player is rooted for (cannot move or be moved by movement attacks)
    * @param i, the new rootDuration of the player
    */ 
  public void setRoot(int i){
    rootDuration = i;
  }
  
   /**
    * setFlag
    * setter for the flag of the player
    * the flag represents if this player is currently in posession of the flag
    * @param b, the new flag of the player
    */ 
  public void setFlag(boolean b){
    flag = b;
  }
  
   /**
    * addHealth
    * adds health to this player
    * the health cannot be added over 100
    * @param i, the amount of health to be added
    */ 
  public void addHealth(int i){
    health+=i;
    if(health>100){
      health = 100;
    }
  }
  
  /**
   * getX
   * getter for x
   * @return int, the horizontal location of this object
   */ 
  public int getX(){
    return (int)Math.round(x);
  }
  /**
   * getY
   * getter for y
   * @return int, the vertical location of this object
   */ 
  public int getY(){
    return (int)Math.round(y);
  }
  
  /**
   * getHealth
   * getter for health
   * @return int, the current health of this object
   */ 
  public int getHealth(){
    return health;
  }
  
  /**
   * getFlag
   * getter for flag
   * @return boolean, true if this player currently has the flag
   */ 
  public boolean hasFlag(){
    return flag;
  }
  
  /**
   * getTeam
   * getter for team
   * @return int, the team this object belongs to
   */ 
  public int getTeam(){
    return team;
  }
  
  /**
   * getDirection
   * getter for yDirection and xDirection
   * @return String, the yDirection followed by a space and then xDirection
   */ 
  public String getDirection(){
    return yDirection+" "+xDirection;
  }
  
  /**
   * getAction
   * getter for currentAction
   * @return int, identifier of the current action (-1 if not in action)
   */ 
  public int getAction(){
    if(currentAction==null){
      return -1;
    } 
    return currentAction.getAttackIdentifier();
  }
  
  /**
   * getAttackDirection
   * getter attackDirection
   * @return double, the direction of this object's attack
   */ 
  public double getAttackDirection(){
    return attackDirection;
  }
  
  /**
   * getCurrentAction
   * getter for currentAction
   * @return Attack, the current action of this object
   */ 
  public Attack getCurrentAction(){
    return currentAction;
  }
  
  /**
   * isInvul
   * getter for invulDuration
   * @return boolean, true if this player is invulnerable
   */ 
  public boolean isInvul(){
    if(invulDuration>0){
      return true;
    }
    return false;
  }
  
  /**
   * getRespawnCounter
   * getter for respawnCounter
   * @return int, the amount of frames until this player respawns
   */ 
  public int getRespawnCounter(){
    return respawnCounter;
  }
  
  /**
   * getWeapon
   * getter for Weapon
   * @return String, the name of the weapon this player uses
   */ 
  public String getWeapon(){
    if(weapon instanceof Bow){
      return "bo";
    }
    return "sw";
  }
  
  /**
   * getWeaponObj
   * other getter for Weapon
   * @return Weapon, the Weapon object of this player
   */ 
  public Weapon getWeaponObj(){
    return weapon;
  }
  public void processAnimationCounter(){
    if(respawnCounter>0){
      respawnCounter--;
      if(respawnCounter == 0){
        health = 100;
        if(team == 1){
          x = 600;
          y = 250;
        } else {
          x = 600;
          y = 1600;
        }
      }
    }
    if(moving){
      if(animationCounter<runAnim.length-1){
        animationCounter++;
      } else {
        animationCounter = 0;
      }
    } else {
      animationCounter = 0;
    }
    if(currentAction != null){
      if(actionCounter == currentAction.getDuration()){
        currentAction = null;
        actionStun = 0;
        attackDirection = 0;
      } else {
        actionCounter++;
        actionStun--;
      }
    }
    if(moveStun>0){
      moveStun--;
    }
    if(rootDuration>0){
      rootDuration--;
    }
    if(invulDuration>0){
      invulDuration--;
    }
    weapon.processCooldown();
  }
  public void processInput(boolean[] input, int[] mouseInput){
    boolean movementInput = false;
    if(input[0]){
      movingUp = true;
      movementInput = true;
      //tempYDirection-=1;
    }
    if(input[1]){
      movingDown = true;
      movementInput = true;
      //tempYDirection+=1;
    }
    if(input[2]){
      movingRight = true;
      movementInput = true;
      //tempXDirection+=1;
    }
    if(input[3]){
      movingLeft = true;
      movementInput = true;
      //tempXDirection-=1;
    }
    if(input[4]){
      movingUp = false;
      //movementInput = true;
      if((movingLeft && !movingRight)||(movingRight && !movingLeft)){
        yDirection = 1;
      }
    }
    if(input[5]){
      movingDown = false;
      //movementInput = true;
      if((movingLeft && !movingRight)||(movingRight && !movingLeft)){
        yDirection = 1;
      }
    }
    if(input[6]){
      movingRight = false;
      if((movingUp && !movingDown)||(movingDown && !movingUp)){
        xDirection = 1;
      }
    }
    if(input[7]){
      movingLeft = false;
      if((movingUp && !movingDown)||(movingDown && !movingUp)){
        xDirection = 1;
      }
    }
    moving = false;
    if(movementInput){
      yDirection = 1;
      xDirection = 1;
    }
    if(movingUp && !movingDown){
      yDirection = 0;
      moving = true;
    }
    if(movingDown && !movingUp){
      yDirection = 2;
      moving = true;
    }
    if(movingLeft && !movingRight){
      xDirection = 0;
      moving = true;
    }
    if(movingRight && !movingLeft){
      xDirection = 2;
      moving = true;
    }
    if(!moving){
      animationCounter = 0;
    }
    
    if(actionStun<=0){
      if(input[8] && weapon.getSkill1Cooldown() <=0 && !(flag && weapon.getAttack(2) instanceof MovingAttack)){
        attackDirection = getDegrees(mouseInput[0], mouseInput[1], mouseInput[2]/2, (mouseInput[3]/2)+30);
        currentAction = weapon.getAttack(2);
        actionCounter = -1;
        actionStun = weapon.getAttack(2).getSelfStun()+1;
        ((Skill)currentAction).activate(this);
        
      } else if(input[9] && mouseInput[0]!=-1 && mouseInput[1]!=-1){
        //attackDirection = Math.atan((mouseInput[0] - (mouseInput[2]/2))  / (mouseInput[1] - (mouseInput[3]/2)));
        attackDirection = getDegrees(mouseInput[0], mouseInput[1], mouseInput[2]/2, (mouseInput[3]/2)+30);
        //System.out.println(attackDirection);
        //System.out.println(attackDirection);
        /*if(weapon.getAttack1() == null){
          System.out.println("ERROR");
        } else {
          System.out.println("REACHED");
        }*/
        currentAction = weapon.getAttack(1); 
        actionCounter = -1;
        actionStun = weapon.getAttack(1).getSelfStun()+1;
      }
    }
  }
  private double getDegrees(double x, double y, double fx, double fy){
    double angle1 = Math.atan2(0 - fy, fx - fx);
    double angle2 = Math.atan2(y - fy, x - fx);
    return angle2-angle1;
  }
  public void processMovement(){
    if(flag){
      moveSpeed = weapon.getMoveSpeed()-5;
    } else{
      moveSpeed = weapon.getMoveSpeed();
    }
    if(rootDuration<=0){
      if(moveStun <= 0){
        if(movingUp){
          y-=moveSpeed;
        }
        if(movingDown){
          y+=moveSpeed;
        }
        if(movingRight){
          x+=moveSpeed;
        }
        if(movingLeft){
          x-=moveSpeed;
        }
      }
      if(currentAction!=null && currentAction instanceof MovingAttack){
        x+= Math.sin(attackDirection)*((MovingAttack)currentAction).getXMove(actionCounter);
        y+= -Math.cos(attackDirection)*((MovingAttack)currentAction).getXMove(actionCounter);
      }
    }
    if(x<0){
      x = 0;
    }
    if(y<0){
      y = 0;
    }
    if(x>1200){
      x = 1200;
    }
    if(y>1450){
      y = 1450;
    }
  }
  public void processHitBox(SimpleLinkedList<Projectile> projArr){
    hitbox = null;
    if(currentAction != null){
      if(currentAction.getHitBox()[actionCounter]!= null){
        //Rectangle[] currentHitbox = new ;
        hitbox = new Shape[currentAction.getHitBox()[actionCounter].length];
        AffineTransform t = new AffineTransform();
        t.rotate(attackDirection, x+29, y+17);
        for(int i = 0; i<currentAction.getHitBox()[actionCounter].length; i++){
          if(currentAction.getHitBox()[actionCounter][i]!=null){
            Rectangle tempHitBox = new Rectangle((int)(x+currentAction.getHitBox()[actionCounter][i].getX()), (int)(y+currentAction.getHitBox()[actionCounter][i].getY()), (int)(currentAction.getHitBox()[actionCounter][i].getWidth()), (int)(currentAction.getHitBox()[actionCounter][i].getHeight()));
            hitbox[i] = t.createTransformedShape(tempHitBox);
          }
        }
      }
      if(currentAction instanceof ProjectileSpawning && currentAction.getProjectile(actionCounter)!=null){
        //System.out.println("REACHED");
        for(int i = 0; i<currentAction.getProjectile(actionCounter).length; i++){
          if(currentAction.getProjectile(actionCounter)[i]!= null){
            if(currentAction.getProjectile(actionCounter)[i] instanceof BowProj2){
              //System.out.println("REACHED");
              projArr.add(new BowProj2((BowProj2)currentAction.getProjectile(actionCounter)[i], x+currentAction.getProjectileX(actionCounter, i), y+currentAction.getProjectileY(actionCounter, i), attackDirection, team));
            } else {
              projArr.add(new Projectile(currentAction.getProjectile(actionCounter)[i], x+currentAction.getProjectileX(actionCounter, i), y+currentAction.getProjectileY(actionCounter, i), attackDirection, team));
            }
            //System.out.println(Math.toDegrees(attackDirection));
            //System.out.println(x+currentAction.getProjectileX(actionCounter, i)+" "+y+currentAction.getProjectileY(actionCounter, i));
          }
        }
      }
    }
  }
  public Rectangle getHurtbox(){
    return new Rectangle((int)x, (int)y, 20, 50);
  }
  public Shape[] getHitBox(){
    /*AffineTransform t2 = new AffineTransform();
    Rectangle hitBox = new Rectangle (x, y-46, 59, 65);
    t2.rotate(thisPlayer.getAttackDirection(), x+29, y+17);
    Shape rotatedRect = t2.createTransformedShape(hitBox);
    ((Graphics2D)g).draw(rotatedRect);*/
    return hitbox;
  }
  public void hurt(Attack a){
    health-=a.getDamage();
    moveStun+=a.getMoveStun();
    invulDuration+=a.getHitInvul();
    if(health<=0){
      respawnCounter = 150;
      hitbox = null;
      movingUp = false;
      movingDown = false;
      movingLeft = false;
      movingRight = false;
    }
  }
  public void hurt(Projectile a){
    health-=a.getDamage();
    moveStun+=a.getMoveStun();
    invulDuration+=a.getHitInvul();
    if(a instanceof BowProj2){
      ((BowProj2)a).onHit(this);
    }
    if(health<=0){
      respawnCounter = 150;
      hitbox = null;
      movingUp = false;
      movingDown = false;
      movingLeft = false;
      movingRight = false;
    }
  }
  public String getImage(){
    if(currentAction != null && currentAction instanceof Skill && ((Skill)currentAction).getPlayerAnim() != null){
      if(((Skill)currentAction).getPlayerAnim()[actionCounter] == 72){
        return "72";
      }
      return Integer.toString(((Skill)currentAction).getPlayerAnim()[actionCounter]+(8*(directionMatrix[yDirection][xDirection]))+36);
    }
    if(moving){
      if (currentAction == null){
        return Integer.toString(runAnim[animationCounter]+(8*(directionMatrix[yDirection][xDirection])));
      } else {
        return Integer.toString(runAnim[animationCounter]+(8*(directionMatrix[yDirection][xDirection]))+36);
      }
    } else {
      if(currentAction == null){
        return Integer.toString((directionMatrix[yDirection][xDirection]));
      } else {
        return Integer.toString((directionMatrix[yDirection][xDirection])+36);
      }
    }
  }
  public String getActionImage(){
    if(currentAction == null){
      return "-1";
    } else {
      return Integer.toString(currentAction.getAttackAnim(actionCounter));
    }
  }
}