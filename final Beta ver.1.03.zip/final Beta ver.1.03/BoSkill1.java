import java.awt.Rectangle;
class BoSkill1 extends Skill implements ProjectileSpawning{
  int cooldown = 120;
  BoSkill1 (int [] atkAnim, Rectangle [][] hitbox, Projectile [][] projectile, double[][][] projectileLocation){
    super(2, atkAnim, hitbox, 0, 0, 7, 2, -24, -10, 195, 108, projectile, projectileLocation);
  }
  @Override
  public int[] getPlayerAnim(){
    return null;
  }
  @Override
  public int getCoolDown(){
    return cooldown;
  }
  @Override
  public void activate(Player p){
    p.getWeaponObj().setSkill1Cooldown(cooldown);
  }
}