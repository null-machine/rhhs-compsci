interface ProjectileSpawning{
  public Projectile[] getProjectile(int i);
  public double getProjectileX(int i, int j);
  public double getProjectileY(int i, int j);
}