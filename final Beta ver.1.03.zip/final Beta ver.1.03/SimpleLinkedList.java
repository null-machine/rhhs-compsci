// ********************** Simple Linked List class in the linked list *********
class SimpleLinkedList<E> { 
    private Node<E> head;
    
    
    public void add(E item) { 
      Node<E> tempNode = head;
      
      if (head==null) {
        head=new Node<E>(item,null);
        return;
      }
    
      while(tempNode.getNext()!=null) { 
        tempNode = tempNode.getNext();
      }
      
      tempNode.setNext(new Node<E>(item,null));
      return;
      
    }
         

    public boolean isEmpty(){
      if(head == null){
        return true;
      }
      return false;
    }
    
    public E get(int index) {
      if (head == null){
        //System.out.println("Empty List");
        return null;
      }
      Node<E> tempNode = head;
      for(int i = 0; i<index; i++){
        if (tempNode.getNext()!= null){
          tempNode = tempNode.getNext();
        } else {
          System.out.println("array out of bounds");
          return null;
        }
      }
      return tempNode.getItem();
    }
    
    public int indexOf(E item) {
      if (head == null){
        //System.out.println("Empty List");
        return -1;
      }
      Node<E> tempNode = head;
      int counter = 0;
      /*do{
        if (tempNode.getItem() == item){
          return counter;
        }
        counter++;
        tempNode = tempNode.getNext();
      }while (tempNode!= null);*/
      for(int i = 0; i<size(); i++){
        if (tempNode != null && tempNode.getItem().equals(item)){
          return i;
        }
        tempNode = tempNode.getNext();
      }
      return -1;
    }
    
    public E remove(int index) { 
      E item;
      if (head == null){
        //System.out.println("Empty List");
        return null;
      }
      if (index == 0){
        item = head.getItem();
        head = head.getNext();
        return item;
      }
      Node<E> tempNode = head;
      for(int i = 0; i<index-1; i++){
        if(tempNode.getNext() != null){
          tempNode = tempNode.getNext();
        } else {
          System.out.println("array out of bounds");
          return null;
        }
      }
      //if (tempNode.getNext()== null){
        //prevNode.setNext(null);
      //} else {
      if (tempNode.getNext()== null){
        item = null;
        tempNode.setNext(null);
      } else {
        item = tempNode.getNext().getItem();
        tempNode.setNext(tempNode.getNext().getNext());
      }
      return item;
    }
    
    public boolean remove(E item) { 
      /*if (head== null){
        System.out.println("Empty List");
        return false;
      }
      if (head.getItem() == item){
        remove(0);
        return true;
      }
      Node<E> tempNode = head;
      int counter = 0;
      while(tempNode.getNext()!=null) { 
        counter++;
        tempNode=tempNode.getNext();
        if (tempNode.getItem() == item){
          remove(counter);
          return true;
        }
      }
      //remove(indexOf(item));
      //System.out.println("Item Not Found");
      return false;*/
      if (indexOf(item)==-1)
        return false;
      
      if (remove(indexOf(item))==null)
        return false;
      
      return true;
    }
    
    public void clear() { 
      head = null;
    }
    
    public int size() {
      if (head == null){
        return 0;
      }
      Node<E> tempNode = head;
      int counter = 1;
      while(tempNode.getNext() != null){
        tempNode = tempNode.getNext();
        counter++;
      }
      return counter;
    }

}



