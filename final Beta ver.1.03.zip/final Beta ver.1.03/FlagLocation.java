import java.awt.Rectangle;
class FlagLocation{
  boolean flag;
  Rectangle hitbox;
  int team;
  FlagLocation(int x,int y,int width,int height,int team){
    this.hitbox = new Rectangle(x, y, width, height);
    this.team = team;
    this.flag = true;
  }
  public void setFlag(boolean b){
    flag = b;
  }
  public boolean hasFlag(){
    return flag;
  }
  public Rectangle getHitbox(){
    return hitbox;
  }
  public int getTeam(){
    return team;
  }
}