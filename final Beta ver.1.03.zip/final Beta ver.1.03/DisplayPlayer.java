class DisplayPlayer{
  int x;
  int y;
  int health;
  int team;
  int xDirection;
  int yDirection;
  int image;
  boolean hasFlag;
  int action;
  int actionImage;
  double attackDirection;
  Weapon weapon = new Sword();
  int respawnCounter;
  int skill1CD;
  DisplayPlayer(){
  }
  DisplayPlayer(int x, int y, int playerImage, int yDirection, int xDirection, boolean hasFlag, int action, int actionImage, double attackDirection, int health, int team, int respawnCounter, Weapon weapon, int skill1CD){
    this.x = x;
    this.y = y;
    this.image = playerImage;
    this.xDirection = xDirection;
    this.yDirection = yDirection;
    this.hasFlag = hasFlag;
    this.action = action;
    this.actionImage = actionImage;
    this.attackDirection = attackDirection;
    this.health = health;
    this.team = team;
    this.respawnCounter = respawnCounter;
    this.weapon = weapon;
    this.skill1CD = skill1CD;
  }
  public void setX(int i){
    x = i;
  }
  public void setY(int i){
    y = i;
  }
  public void setXDirection(int i){
    xDirection = i;
  }
  public void setYDirection(int i){
    yDirection = i;
  }
  public void setFlag(boolean b){
    hasFlag = b;
  }
  public int getX(){
    return x;
  }
  public int getY(){
    return y;
  }
  public int getHealth(){
    return health;
  }
  public int getTeam(){
    return team;
  }
  public int getXDirection(){
    return xDirection;
  }
  public int getYDirection(){
    return yDirection;
  }
  public boolean getFlag(){
    return hasFlag;
  }
  public int getImage(){
    return image;
  }
  public int getAction(){
    return action;
  }
  public int getActionImage(){
    return actionImage;
  }
  public double getAttackDirection(){
    return attackDirection;
  }
  public Weapon getWeapon(){
    return weapon;
  }
  public int getRespawnCounter(){
    return respawnCounter;
  }
  public int getSkill1CD(){
    return skill1CD;
  }
}