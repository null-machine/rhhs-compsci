import java.awt.Rectangle;
class BowProj2 extends Projectile{
  BowProj2 (int [] projectileAnim, Rectangle [][] hitbox){
    super(projectileAnim, 40, hitbox, 20, 4, 1);
  }
  
  BowProj2 (BowProj2 projectileCopy, double x, double y, double direction, int team){
    super(projectileCopy, x, y, direction, team);
  }
  
  public void onHit(Player p){
    p.setRoot(20);
  }
}