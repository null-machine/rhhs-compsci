import java.awt.Rectangle;
class SwSkill1 extends Skill implements MovingAttack{
  int cooldown = 90;
  int[] playerAnim;
  double [] xMove;
  SwSkill1 (int [] atkAnim, Rectangle [][] hitbox, double [] xMove){
    super(2, atkAnim, hitbox, 30, 4, 7, 4, 6, -65, 76, 330, null, null);
    int [] playerAnim = {6, 72, 72, 7, 7, 7, 7, 7, 7, 8, 8};
    this.playerAnim = playerAnim;
    this.xMove = xMove;
  }
  public int[] getPlayerAnim(){
    return playerAnim;
  }
  public int getCoolDown(){
    return cooldown;
  }

  public void activate(Player p){
    double direction = Math.toDegrees(p.getAttackDirection());
    if(direction<337.5 && direction>=202.5){
      p.setXDirection(0);
    } else if (direction<157.5 && direction>= 22.5){
      p.setXDirection(2);
    } else {
      p.setXDirection(1);
    }
    if(direction<67.5 || direction>= 292.5){
      p.setYDirection(0);
    } else if(direction<247.5 && direction>=112.5){
      p.setYDirection(2);
    } else {
      p.setYDirection(1);
    }
    p.setMoveStun(7);
    p.getWeaponObj().setSkill1Cooldown(cooldown);
  }
  
  /*
   * getXMove
   * getter for xMove 
   * @param int i, the index of the xMove array needed
   * @return double xMove, the distance this attack moves the player on the ith frame
   */ 
  public double getXMove(int i){
    if (xMove != null){
      return xMove[i];
    } 
    return 0;
  }
}