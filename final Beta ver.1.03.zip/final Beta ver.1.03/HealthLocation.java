import java.awt.Rectangle;
class HealthLocation{
  int cooldown;
  Rectangle hitbox;
  HealthLocation(int x,int y,int width,int height){
    this.hitbox = new Rectangle(x, y, width, height);
  }
  public boolean getCooldown(){
    if(cooldown<=0){
      return false;
    }
    return true;
  }
  public void processCooldown(){
    if(cooldown>0){
      cooldown--;
    }
  }
  public void heal(Player p){
    if(p.getHealth()<100){
      p.addHealth(35);
      cooldown = 300;
    }
  }
  public Rectangle getHitbox(){
    return hitbox;
  }

}