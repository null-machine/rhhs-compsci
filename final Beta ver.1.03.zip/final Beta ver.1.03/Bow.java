import java.awt.Rectangle;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
class Bow extends Weapon{
  private static Image [] sprites;
  private static Attack atk1;
  private static Skill skill1;
  private static int idleX;
  private static int idleY;
  private static int moveSpeed;
  private int skill1CD;
  static void loadAssets(){
    sprites = new Image[8];
    Image[] arrow1 = new Image[2];
    //Image arrow2;
    try{
      for(int i = 1; i<=4; i++){
        sprites[i-1] = ImageIO.read(new File("bow000"+i+".png"));
      }
      for(int i = 1; i<=4; i++){
        if (i>=10){
          sprites[i+3] = ImageIO.read(new File("atkbo100"+i+".png"));
        } else {
          sprites[i+3] = ImageIO.read(new File("atkbo1000"+i+".png"));
        }
      }
      arrow1[0] = ImageIO.read(new File("projbo10001.png"));
      arrow1[1] = ImageIO.read(new File("projbo10002.png"));
    } catch(IOException e){
      System.out.println("Image loading failed");
      e.printStackTrace();
    }
    idleX = -10;
    idleY = -20;
    int [] atk1Anim = {4, 5, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7};
    //Rectangle [][] atk1hitBox = new Rectangle [13][1];
    //atk1hitBox[1][0] = new Rectangle(0, -46, 59, 65);
    //atk1hitBox[2][0] = new Rectangle(0, -46, 59, 65);
    //atk1 = new Attack(atk1Anim, atk1hitBox, 15, 3, 5, 2, 20, null, null, -79, -37, 195, 108);
    Rectangle [][] arrow1HitBox = new Rectangle[1][1];
    arrow1HitBox[0][0] = new Rectangle(0, 0, 10, 38);
    Projectile proj1 = new Projectile(new int[1], 40, arrow1HitBox, 15, 4, 0);
    Projectile [][] atk1proj = new Projectile[13][1];
    atk1proj[1][0] = proj1;
    double [][][]atk1projLocation = new double [13][1][2];
    atk1projLocation[1][0][0] = 21;
    atk1projLocation[1][0][1] = -3;
    atk1 = new Attack(1, atk1Anim, new Rectangle [13][1], 0, 0, 7, 2, -24, -10, 195, 108, atk1proj, atk1projLocation);
    
    Projectile proj2 = new BowProj2(new int[1], arrow1HitBox);
    Projectile [][] atk2proj = new Projectile[13][1];
    atk2proj[1][0] = proj2;
    skill1 = new BoSkill1(atk1Anim, new Rectangle [13][1], atk2proj, atk1projLocation);
    
    moveSpeed = 13;
    //System.out.println("Assets Loaded");
    
  }
  public int getIdleX(){
    return idleX;
  }
  public int getIdleY(){
    return idleY;
  }
  public Image[] getSprites(){
    return sprites;
  }
  public Attack getAttack(int i){
    if(i == 1){
      return this.atk1;
    } else if(i == 2){
      return this.skill1;
    }
    return null;
  }
  public int getMoveSpeed(){
    return moveSpeed;
  }
  public void setSkill1Cooldown(int i){
    skill1CD = i;
  }
  public int getSkill1Cooldown(){
    return skill1CD;
  }
  public void processCooldown(){
    if(skill1CD>0){
      skill1CD--;
    }
  }
}