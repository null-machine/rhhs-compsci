import java.awt.Rectangle;
abstract class Skill extends Attack{
  Skill (int attackIdentifier, int [] atkAnim, Rectangle [][] hit, int damage, int moveStun, int selfStun, int hitInvul, int imageX, int imageY, int rotateX, int rotateY/*, Effect [][] effect, int [][][] effectLocation*/, Projectile [][] projectile, double[][][] projectileLocation){
    super(attackIdentifier, atkAnim, hit, damage, moveStun, selfStun, hitInvul, imageX, imageY, rotateX, rotateY, projectile, projectileLocation);
  }
  public abstract int[] getPlayerAnim();
  public abstract int getCoolDown();
  public abstract void activate(Player p);
}