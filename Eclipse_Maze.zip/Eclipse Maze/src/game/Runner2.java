package game;

public class Runner2 {
	public static void main(String [] args) {
		Game game = new Game();
		game.start();
	}
}
