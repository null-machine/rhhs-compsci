package game;

public class Runner1 {
	public static void main(String [] args) {
		Game game = new Game();
		game.start();
	}
}
