### class interactions
- GDP determines user intent and gui output
- when adding or modifying shapes, GDP passes the scanner to the shape class! this allows class specific user prompts to be placed in the classes instead of the GDP
- saving and loading is done by the serializer
