
public class Jalse {

  // E:\Resources\jdk-12.0.1\bin\javac.exe *.java & E:\Resources\jdk-12.0.1\bin\java.exe Jalse.java

  public static void main(String[] args) {
    GameState gs = new GameState();
    Engine engine = new Engine();
    MainMenu menu = new MainMenu(gs, engine);
    Renderer renderer = new Renderer(gs, engine);
    Results results = new Results(gs, engine);
    engine.init(menu, renderer, results);
  }
}
