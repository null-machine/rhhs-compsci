import java.util.List;
import java.util.Set;

// simulates the game
public class PhysEngine implements Updatable {

  private Engine engine;
  private GameState gs;

  private void updateParticles(long deltaTime) {
    for (Particle particle : gs.particles) {
      particle.update(deltaTime);
    }
  }

  private void checkCollisions(Racer racer) {
    racer.colliding = false;
    for (Wall wall : gs.walls) {
      if (racer.collider.intersects(wall.collider)) {
        if (!racer.colliding) {
          racer.collide();
        }
        racer.colliding = true;
      }
    }
  }

  public void update(long deltaTime) {
    boolean allWon = true;
    for (Racer racer : gs.racers) { // sigh gotta import iterator
      if (racer.won) {
        continue;
      } else {
        allWon = false;
      }
      checkCollisions(racer);
      racer.update(deltaTime);
      if (gs.finish.collider.contains(racer.collider)) {
        racer.win();
      }
    }
    if (allWon) {
      engine.loadResults();
    }
    updateParticles(deltaTime);
  }

  public PhysEngine(GameState gs, Engine engine) { // TODO renderer only needs gamestate
    this.gs = gs;
    this.engine = engine;
  }
}
