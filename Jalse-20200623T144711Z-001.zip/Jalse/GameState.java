import java.util.HashSet;
import java.util.ArrayList;

/**
* GameState.java
* A data container holding shared information.
* One of these is created on initialization, and manipulated by all classes.
* @author Glen Wang
*/
public class GameState {
	public HashSet<Racer> racers;
  public ArrayList<Racer> racersDone;
  public HashSet<Wall> walls;
  public Wall finish;
  public PoolingQueue<Particle> particles;

	public Controller playerOne;
	public Controller playerTwo;
	public Controller mouse;

	public void clear() {
		racers.clear();
		racersDone.clear();
		walls.clear();
		finish = null;
	}

	public GameState() {
		racers = new HashSet<Racer>();
		racersDone = new ArrayList<Racer>();
		walls = new HashSet<Wall>();
		ParticlePool pp = new ParticlePool(200); // just has to be big
		particles = pp.getParticles();

		Input input = new Input();
		playerOne = new WASD(input);
		playerTwo = new Arrows(input);
		mouse = new Mouse(input);
	}
}
