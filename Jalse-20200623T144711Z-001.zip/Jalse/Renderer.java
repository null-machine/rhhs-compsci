import javax.swing.JPanel;

import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;

// renders the game
public class Renderer extends JPanel implements Updatable {

  private Engine engine;
  private GameState gs;
  private PhysEngine pe;

  private GeoVector camPos;
  private double camZoom;
  private double zoomPercent;

  private void paintRect(Graphics g, Rectangle rect, Color color) {
    g.setColor(color);
    g.fillRect(
    (int)(camZoom * (rect.x - camPos.x)),
    (int)(camZoom * (rect.y - camPos.y)),
    (int)(camZoom * rect.width + 1),
    (int)(camZoom * rect.height + 1)
    );
  }

  private <T> void paintIterable(Graphics g, Iterable<T> walls) {
    for (T wall : walls) {
      paintRect(g, ((Wall)wall).collider, ((Wall)wall).color);
    }
  }

  private void paintRacerTags(Graphics g, Iterable<Racer> racers) {
    g.setColor(Color.GRAY);
    g.setFont(new Font("Consolas", Font.PLAIN, 24));

    for (Racer racer : gs.racers) {
      g.drawString(
      "" + racer.tag,
      (int)(camZoom * (racer.pos.x - camPos.x) - 7),
      (int)(camZoom * (racer.pos.y - camPos.y) + 7)
      );
    }
  }

  private GeoVector getRacerBounds() {
    // GeoVector pos = gs.racers.get(0).pos;
    GeoVector pos = GeoVector.zero;
    GeoVector min = pos.copy();
    GeoVector max = pos.copy();
    GeoVector racerPos;
    for (Racer racer : gs.racers) {
      racerPos = racer.pos;
      min.x = (racerPos.x < min.x) ? racerPos.x : min.x;
      min.y = (racerPos.y < min.y) ? racerPos.y : min.y;
      max.x = (racerPos.x > max.x) ? racerPos.x : max.x;
      max.y = (racerPos.y < max.y) ? racerPos.y : max.y;
    }
    return new GeoVector(max.x - min.x, max.y - min.y);
  }

  private void captureRacers() {
    double minZoom = 0.5;
    double maxX = getSize().width / Math.abs(gs.finish.pos.x);
    double maxY = getSize().height / Math.abs(gs.finish.pos.y);
    double maxZoom = (maxX < maxY) ? maxX : maxY;
    double zoomScale = 2; // wont be necessary after node bounds
    maxZoom /= zoomScale;
    GeoVector bounds = getRacerBounds();
    double zoomMult = bounds.mag() / gs.finish.pos.mag();
    zoomMult *= zoomScale;
    zoomMult = (zoomMult > 1.0) ? 1.0 : zoomMult;
    camZoom = minZoom - (minZoom - maxZoom) * zoomMult;
    zoomPercent = (minZoom - camZoom) / (minZoom - maxZoom);
  }

  private void centerRacers() {
    camPos = GeoVector.zero;
    for (Racer racer : gs.racers) {
      camPos = camPos.add(racer.pos);
    }
    camPos = camPos.mult(1.0 / gs.racers.size());

    GeoVector center = GeoVector.zero.lerp(gs.finish.pos, 0.5);
    GeoVector dir = camPos.sub(center);
    camPos = camPos.sub(dir.mult(zoomPercent));

    camPos = camPos.sub(new GeoVector(getSize().width / 2 / camZoom, getSize().height / 2 / camZoom));
  }

  private void updateCamera() {
    captureRacers();
    centerRacers();
  }

  @Override
  public void update(long deltaTime) {
    pe.update(deltaTime);
    repaint();
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    setDoubleBuffered(true);
    setBackground(Color.BLACK);

    updateCamera();
    paintIterable(g, gs.walls);
    paintIterable(g, gs.racers);
    paintIterable(g, gs.particles);
    paintRacerTags(g, gs.racers);
    paintRect(g, gs.finish.collider, gs.finish.color);

    repaint();
  }

  public Renderer(GameState gs, Engine engine) {
    this.gs = gs;
    this.engine = engine;
    pe = new PhysEngine(gs, engine);

    camPos = GeoVector.zero;
    camZoom = 0.5;
  }
}
