import javax.swing.JPanel;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;

// sets map and racers
public class Results extends JPanel implements Updatable {

  private Engine engine;
  private GameState gs;
  private long minWait = 2000;
  private long currentWait;

  @Override
  public void update(long deltaTime) {
    currentWait -= deltaTime;
    if (currentWait <= 0) {
      if (gs.playerOne.getDir().equals(GeoVector.zero) || gs.playerTwo.getDir().equals(GeoVector.zero)) {
        engine.loadMenu();
        currentWait = minWait;
      }
    }
    repaint();
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    setDoubleBuffered(true);
    setBackground(Color.BLACK);

    g.setColor(Color.WHITE);
    g.setFont(new Font("Consolas", Font.BOLD, 24));

    g.drawString("RESULTS", getSize().width, getSize().height);

    g.setFont(new Font("Consolas", Font.PLAIN, 24));

    for (int i = 1; i <= gs.racersDone.size(); ++i) {
      String res = "" + i + ": " + gs.racersDone.get(i);
    }

    repaint();
  }

  public Results(GameState gs, Engine engine) {
    this.engine = engine;
    this.gs = gs;
    currentWait = minWait;
  }
}
