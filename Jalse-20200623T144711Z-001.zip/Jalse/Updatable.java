

public interface Updatable {

  /**
  *
  */
  abstract public void update(long deltaTime);
}
