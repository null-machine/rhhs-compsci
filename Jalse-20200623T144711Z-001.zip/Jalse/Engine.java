import javax.swing.JFrame;
import javax.swing.JPanel;

public class Engine extends JFrame { // refactor into clock or updater?

  private MainMenu menu;
  private Renderer renderer;
  private Results results;
  private Updatable focus;

  private GameState gameState;

  private void loadFocus(Updatable focus, String title) {
    this.focus = focus;
    setTitle(title);
    getContentPane().removeAll();
    getContentPane().add((JPanel)focus);
    revalidate();
  }

  public void loadSplash() {
    loadMenu();
  }

  public void loadMenu() {
    loadFocus(menu, "Main Menu");
  }

  public void loadRenderer() {
    loadFocus(renderer, "Jalse");
  }

  public void loadResults() {
    loadFocus(results, "Results");
  }

  public void init(MainMenu menu, Renderer renderer, Results results) {
    // called seperately from constructor to avoid linkage error
    setSize(1280, 720);
    setExtendedState(JFrame.MAXIMIZED_BOTH);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    this.menu = menu;
    this.renderer = renderer;
    this.results = results;

    loadSplash();

    setVisible(true);

    Thread focusUpdater = new Thread(new FocusUpdater());
    focusUpdater.start();
  }

  private class FocusUpdater implements Runnable {
    private long oldTime = System.currentTimeMillis();
    private long deltaTime;
    private final long targDeltaTime = 10;

    @Override
    public void run() {
      while (this != null) {
        deltaTime = System.currentTimeMillis() - oldTime;
        focus.update(deltaTime);
        oldTime = System.currentTimeMillis();
        try { Thread.sleep(targDeltaTime); } catch (Exception exc) {}
      }
    }
  }
}
